package com.example.safetyapp;

public class AddRelative {
}
