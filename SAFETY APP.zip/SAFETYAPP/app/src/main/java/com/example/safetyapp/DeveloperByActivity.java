package com.example.safetyapp;

public class DeveloperByActivity {
}
