package com.example.safetyapp;

public class HowToSwipe {
}
